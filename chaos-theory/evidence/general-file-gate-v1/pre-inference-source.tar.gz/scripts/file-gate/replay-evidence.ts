/** Fresh source-built replay of actual model proposals, CSV artifacts and the full recorded native ledger. */
import fs from "node:fs/promises";
import { join, resolve } from "node:path";
import { execFileSync } from "node:child_process";
import { deepStrictEqual, equal, ok } from "node:assert";
import { startFileAuthority, fileHash } from "./native";
import { createFileHost } from "./workspace";
import { root } from "../lean-plan-process";
const path = resolve(
  process.argv[2] ?? join(root, "evidence/general-file-gate-v1/live"),
);
const python = JSON.parse(
  execFileSync("python3", ["scripts/file-gate/verify_evaluation.py", path], {
    cwd: root,
    encoding: "utf8",
    timeout: 60000,
  }),
);
ok(python.passed);
const p = JSON.parse(
  await fs.readFile(join(path, "protocol.json"), "utf8"),
).protocol;
const r = JSON.parse(
  await fs.readFile(join(path, "report.json"), "utf8"),
).report;
const expectedNames = [
  "formal/FilePolicy.lean",
  "formal/FilePolicyMain.lean",
  "scripts/file-gate/model.ts",
  "scripts/file-gate/native.ts",
  "scripts/file-gate/workspace.ts",
  "scripts/file-gate/bridge.ts",
  "scripts/file-gate/oracle.py",
  "scripts/file-gate/protocol.py",
  "scripts/file-gate/evaluate.py",
  "scripts/file-gate/verify_evaluation.py",
  "scripts/local_runtime.py",
  "scripts/local_model_interactive.py",
  "scripts/replay_real_model.py",
];
deepStrictEqual(Object.keys(p.sources).sort(), expectedNames.sort());
for (const name of expectedNames)
  equal(
    await fileHash(join(root, name)),
    p.sources[name],
    `Recorded source differs: ${name}`,
  );
const host = await createFileHost(),
  native = await startFileAuthority();
const ledger = JSON.parse(
  await fs.readFile(join(path, "native-ledger.json"), "utf8"),
);
let count = 0,
  successes = 0,
  rejections = 0;
try {
  deepStrictEqual(host.authority(), p.authority);
  equal(host.manifest().versionString, p.nativeManifest.versionString);
  equal(
    host.manifest().pins[host.manifest().executable],
    p.nativeManifest.pins[p.nativeManifest.executable],
  );
  for (const e of r.episodes) {
    const s = await host.resume(
        join(path, "workspaces", e.id),
        e.final.checkpoint,
      ),
      actual = s.snapshot();
    // Absolute historical paths describe origin. Replay verifies actual artifact bytes under the selected local directory.
    deepStrictEqual(
      {
        ...actual,
        artifacts: actual.artifacts.map(({ path: _path, ...a }) => a),
      },
      {
        ...e.final,
        artifacts: e.final.artifacts.map(
          ({
            path: _path,
            ...a
          }: {
            path: string;
            id: string;
            sha256: string;
          }) => a,
        ),
      },
    );
    count++;
  }
  for (const record of ledger) {
    const before = native.records().length;
    let accepted = true;
    try {
      await native.authorize(
        { files: record.request.files, policy: record.request.policy },
        record.request.plans,
      );
    } catch {
      accepted = false;
    }
    equal(accepted, record.response.ok);
    equal(native.records().length, before + 1);
    deepStrictEqual(native.records().at(-1), record);
    if (accepted) successes++;
    else rejections++;
  }
} finally {
  await host.close();
  await native.close();
}
console.log(
  JSON.stringify(
    {
      passed: true,
      realLeanProcess: true,
      actualArtifactWorkspaces: count,
      freshNativeComputations: ledger.length,
      acceptedNativeProfiles: successes,
      rejectedNativeProfiles: rejections,
      originalModelCalls: r.calls.length,
      newInferenceCalls: 0,
      scope:
        "Exact-source independent replay of archived inference, not a new generation experiment, origin authentication or a hostile-host proof.",
    },
    null,
    2,
  ),
);
