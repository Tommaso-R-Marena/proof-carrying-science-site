import PCSReal.Calibration
set_option autoImplicit false
set_option format.width 1000000
open Finset PCSReal.Calibration

namespace PCSCalibrationReplay.M5
def abscissa (i : Fin 14) : ℚ := ([((5 : ℚ) / (1 : ℚ)), ((6 : ℚ) / (1 : ℚ)), ((7 : ℚ) / (1 : ℚ)), ((8 : ℚ) / (1 : ℚ)), ((9 : ℚ) / (1 : ℚ)), ((10 : ℚ) / (1 : ℚ)), ((11 : ℚ) / (1 : ℚ)), ((12 : ℚ) / (1 : ℚ)), ((13 : ℚ) / (1 : ℚ)), ((14 : ℚ) / (1 : ℚ)), ((15 : ℚ) / (1 : ℚ)), ((16 : ℚ) / (1 : ℚ)), ((17 : ℚ) / (1 : ℚ)), ((18 : ℚ) / (1 : ℚ))] : List ℚ).getD i.val 0
def x (i : Fin 14) (j : Fin 4) : ℚ := abscissa i ^ j.val
def y (i : Fin 14) : ℚ := ([((11 : ℚ) / (100 : ℚ)), ((27 : ℚ) / (100 : ℚ)), ((47 : ℚ) / (100 : ℚ)), ((39 : ℚ) / (50 : ℚ)), ((59 : ℚ) / (50 : ℚ)), ((91 : ℚ) / (50 : ℚ)), ((261 : ℚ) / (100 : ℚ)), ((94 : ℚ) / (25 : ℚ)), ((499 : ℚ) / (100 : ℚ)), ((179 : ℚ) / (25 : ℚ)), ((1193 : ℚ) / (100 : ℚ)), ((2011 : ℚ) / (100 : ℚ)), ((131 : ℚ) / (4 : ℚ)), ((4949 : ℚ) / (100 : ℚ))] : List ℚ).getD i.val 0
def b (j : Fin 4) : ℚ := ([((-83241761 : ℚ) / (1701700 : ℚ)), ((13808923 : ℚ) / (785400 : ℚ)), ((-26958677 : ℚ) / (13613600 : ℚ)), ((422159 : ℚ) / (5834400 : ℚ))] : List ℚ).getD j.val 0
def xr (i : Fin 14) (j : Fin 4) : ℝ := (x i j : ℝ)
def yr (i : Fin 14) : ℝ := (y i : ℝ)
def br (j : Fin 4) : ℝ := (b j : ℝ)
theorem normal_checked : fitCheck x y b = true := by decide +kernel
theorem residual_checked : loss x y b = ((14824431277 : ℚ) / (680680000 : ℚ)) := by decide +kernel
theorem global_optimum : ∀ c : Fin 4 → ℝ,
    (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ) ≤ loss xr yr c := by
  have hs : loss xr yr br = (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ) := by
    calc
      loss xr yr br = ((loss x y b : ℚ) : ℝ) := (cast_loss x y b).symm
      _ = (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ) := by
        simpa only [Rat.cast_div, Rat.cast_intCast, Rat.cast_ofNat, Rat.cast_neg]
          using congrArg (fun a : ℚ => (a : ℝ)) residual_checked
  simpa only [hs] using global_minimum xr yr br (fit_check_sound normal_checked)
theorem excludes_every_better_model (threshold : ℝ)
    (h : threshold < (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ)) :
    ∀ c : Fin 4 → ℝ, threshold < loss xr yr c := by
  intro c
  exact h.trans_le (global_optimum c)
theorem uniform_error_exclusion (ε : ℝ) (he : 0 ≤ ε)
    (hgap : (14 : ℝ) * ε ^ 2 < (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ)) :
    ¬ (∃ c : Fin 4 → ℝ, ∀ i, |yr i - prediction xr c i| ≤ ε) :=
  PCSReal.Calibration.uniform_error_exclusion xr yr (((14824431277 : ℚ) / (680680000 : ℚ)) : ℝ) ε
    global_optimum he (by simpa using hgap)
end PCSCalibrationReplay.M5

#print axioms PCSCalibrationReplay.M5.normal_checked
#print axioms PCSCalibrationReplay.M5.residual_checked
#print axioms PCSCalibrationReplay.M5.global_optimum
#print axioms PCSCalibrationReplay.M5.excludes_every_better_model
#print axioms PCSCalibrationReplay.M5.uniform_error_exclusion
