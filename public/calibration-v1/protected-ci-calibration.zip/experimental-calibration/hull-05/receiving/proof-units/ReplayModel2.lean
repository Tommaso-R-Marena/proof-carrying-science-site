import PCSReal.Calibration
set_option autoImplicit false
set_option format.width 1000000
open Finset PCSReal.Calibration

namespace PCSCalibrationReplay.M2
def abscissa (i : Fin 7) : ℚ := ([((5 : ℚ) / (1 : ℚ)), ((7 : ℚ) / (1 : ℚ)), ((9 : ℚ) / (1 : ℚ)), ((11 : ℚ) / (1 : ℚ)), ((13 : ℚ) / (1 : ℚ)), ((15 : ℚ) / (1 : ℚ)), ((17 : ℚ) / (1 : ℚ))] : List ℚ).getD i.val 0
def x (i : Fin 7) (j : Fin 3) : ℚ := abscissa i ^ j.val
def y (i : Fin 7) : ℚ := ([((3 : ℚ) / (25 : ℚ)), ((43 : ℚ) / (100 : ℚ)), ((109 : ℚ) / (100 : ℚ)), ((123 : ℚ) / (50 : ℚ)), ((231 : ℚ) / (50 : ℚ)), ((289 : ℚ) / (25 : ℚ)), ((69 : ℚ) / (2 : ℚ))] : List ℚ).getD i.val 0
def b (j : Fin 3) : ℚ := ([((315457 : ℚ) / (11200 : ℚ)), ((-2543 : ℚ) / (350 : ℚ)), ((4871 : ℚ) / (11200 : ℚ))] : List ℚ).getD j.val 0
def xr (i : Fin 7) (j : Fin 3) : ℝ := (x i j : ℝ)
def yr (i : Fin 7) : ℝ := (y i : ℝ)
def br (j : Fin 3) : ℝ := (b j : ℝ)
theorem normal_checked : fitCheck x y b = true := by decide +kernel
theorem residual_checked : loss x y b = ((5325863 : ℚ) / (70000 : ℚ)) := by decide +kernel
theorem global_optimum : ∀ c : Fin 3 → ℝ,
    (((5325863 : ℚ) / (70000 : ℚ)) : ℝ) ≤ loss xr yr c := by
  have hs : loss xr yr br = (((5325863 : ℚ) / (70000 : ℚ)) : ℝ) := by
    calc
      loss xr yr br = ((loss x y b : ℚ) : ℝ) := (cast_loss x y b).symm
      _ = (((5325863 : ℚ) / (70000 : ℚ)) : ℝ) := by
        simpa only [Rat.cast_div, Rat.cast_intCast, Rat.cast_ofNat, Rat.cast_neg]
          using congrArg (fun a : ℚ => (a : ℝ)) residual_checked
  simpa only [hs] using global_minimum xr yr br (fit_check_sound normal_checked)
theorem excludes_every_better_model (threshold : ℝ)
    (h : threshold < (((5325863 : ℚ) / (70000 : ℚ)) : ℝ)) :
    ∀ c : Fin 3 → ℝ, threshold < loss xr yr c := by
  intro c
  exact h.trans_le (global_optimum c)
theorem uniform_error_exclusion (ε : ℝ) (he : 0 ≤ ε)
    (hgap : (7 : ℝ) * ε ^ 2 < (((5325863 : ℚ) / (70000 : ℚ)) : ℝ)) :
    ¬ (∃ c : Fin 3 → ℝ, ∀ i, |yr i - prediction xr c i| ≤ ε) :=
  PCSReal.Calibration.uniform_error_exclusion xr yr (((5325863 : ℚ) / (70000 : ℚ)) : ℝ) ε
    global_optimum he (by simpa using hgap)
namespace Q0
def q (j : Fin 3) : ℚ := (((6 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((61 : ℚ) / (112 : ℚ)), ((9 : ℚ) / (28 : ℚ)), ((17 : ℚ) / (112 : ℚ)), ((1 : ℚ) / (28 : ℚ)), ((-3 : ℚ) / (112 : ℚ)), ((-1 : ℚ) / (28 : ℚ)), ((1 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((599 : ℚ) / (448 : ℚ)), ((-43 : ℚ) / (224 : ℚ)), ((3 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((9 : ℚ) / (8 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((9 : ℚ) / (8 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((9 : ℚ) / (8 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((9 : ℚ) / (8 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q0
namespace Q0.Minimax
def w (i : Fin 7) : ℚ := ([((11 : ℚ) / (24 : ℚ)), ((11 : ℚ) / (20 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((-1 : ℚ) / (120 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((5 : ℚ) / (12 : ℚ)), ((1 : ℚ) / (5 : ℚ)), ((-1 : ℚ) / (60 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q0.q a ((61 : ℚ) / (60 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((61 : ℚ) / (60 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((61 : ℚ) / (60 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q0.qr) :
    (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q0.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q0.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q0.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q0.qr truth| ≤ ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q0.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q0.qr truth| ≤ radius) ↔
      ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q0.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q0.Minimax
namespace Q1
def q (j : Fin 3) : ℚ := (((8 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((67 : ℚ) / (336 : ℚ)), ((1 : ℚ) / (4 : ℚ)), ((29 : ℚ) / (112 : ℚ)), ((19 : ℚ) / (84 : ℚ)), ((17 : ℚ) / (112 : ℚ)), ((1 : ℚ) / (28 : ℚ)), ((-41 : ℚ) / (336 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((-7 : ℚ) / (64 : ℚ)), ((59 : ℚ) / (672 : ℚ)), ((-1 : ℚ) / (192 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((209 : ℚ) / (168 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((209 : ℚ) / (168 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((209 : ℚ) / (168 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((209 : ℚ) / (168 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q1
namespace Q1.Minimax
def w (i : Fin 7) : ℚ := ([((0 : ℚ) / (1 : ℚ)), ((9 : ℚ) / (20 : ℚ)), ((9 : ℚ) / (16 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((-1 : ℚ) / (80 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((-23 : ℚ) / (40 : ℚ)), ((2 : ℚ) / (5 : ℚ)), ((-1 : ℚ) / (40 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q1.q a ((41 : ℚ) / (40 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((41 : ℚ) / (40 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((41 : ℚ) / (40 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q1.qr) :
    (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q1.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q1.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q1.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q1.qr truth| ≤ ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q1.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q1.qr truth| ≤ radius) ↔
      ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q1.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q1.Minimax
namespace Q2
def q (j : Fin 3) : ℚ := (((10 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((-3 : ℚ) / (112 : ℚ)), ((5 : ℚ) / (28 : ℚ)), ((33 : ℚ) / (112 : ℚ)), ((9 : ℚ) / (28 : ℚ)), ((29 : ℚ) / (112 : ℚ)), ((3 : ℚ) / (28 : ℚ)), ((-15 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((-417 : ℚ) / (448 : ℚ)), ((53 : ℚ) / (224 : ℚ)), ((-5 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((37 : ℚ) / (28 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((37 : ℚ) / (28 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((37 : ℚ) / (28 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((37 : ℚ) / (28 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q2
namespace Q2.Minimax
def w (i : Fin 7) : ℚ := ([((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((7 : ℚ) / (16 : ℚ)), ((7 : ℚ) / (12 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((-1 : ℚ) / (48 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((-25 : ℚ) / (8 : ℚ)), ((5 : ℚ) / (6 : ℚ)), ((-1 : ℚ) / (24 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q2.q a ((25 : ℚ) / (24 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((25 : ℚ) / (24 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((25 : ℚ) / (24 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q2.qr) :
    (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q2.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q2.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q2.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q2.qr truth| ≤ ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q2.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q2.qr truth| ≤ radius) ↔
      ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q2.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q2.Minimax
namespace Q3
def q (j : Fin 3) : ℚ := (((12 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((-15 : ℚ) / (112 : ℚ)), ((3 : ℚ) / (28 : ℚ)), ((29 : ℚ) / (112 : ℚ)), ((9 : ℚ) / (28 : ℚ)), ((33 : ℚ) / (112 : ℚ)), ((5 : ℚ) / (28 : ℚ)), ((-3 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((-505 : ℚ) / (448 : ℚ)), ((57 : ℚ) / (224 : ℚ)), ((-5 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((37 : ℚ) / (28 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((37 : ℚ) / (28 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((37 : ℚ) / (28 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((37 : ℚ) / (28 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q3
namespace Q3.Minimax
def w (i : Fin 7) : ℚ := ([((-1 : ℚ) / (48 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((7 : ℚ) / (12 : ℚ)), ((7 : ℚ) / (16 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((-119 : ℚ) / (24 : ℚ)), ((1 : ℚ) / (1 : ℚ)), ((-1 : ℚ) / (24 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q3.q a ((25 : ℚ) / (24 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((25 : ℚ) / (24 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((25 : ℚ) / (24 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q3.qr) :
    (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q3.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q3.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q3.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q3.qr truth| ≤ ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q3.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q3.qr truth| ≤ radius) ↔
      ε * (((25 : ℚ) / (24 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q3.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q3.Minimax
namespace Q4
def q (j : Fin 3) : ℚ := (((14 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((-41 : ℚ) / (336 : ℚ)), ((1 : ℚ) / (28 : ℚ)), ((17 : ℚ) / (112 : ℚ)), ((19 : ℚ) / (84 : ℚ)), ((29 : ℚ) / (112 : ℚ)), ((1 : ℚ) / (4 : ℚ)), ((67 : ℚ) / (336 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((-313 : ℚ) / (448 : ℚ)), ((95 : ℚ) / (672 : ℚ)), ((-1 : ℚ) / (192 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((209 : ℚ) / (168 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((209 : ℚ) / (168 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((209 : ℚ) / (168 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((209 : ℚ) / (168 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q4
namespace Q4.Minimax
def w (i : Fin 7) : ℚ := ([((-1 : ℚ) / (80 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((9 : ℚ) / (16 : ℚ)), ((9 : ℚ) / (20 : ℚ)), ((0 : ℚ) / (1 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((-31 : ℚ) / (8 : ℚ)), ((7 : ℚ) / (10 : ℚ)), ((-1 : ℚ) / (40 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q4.q a ((41 : ℚ) / (40 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((41 : ℚ) / (40 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((41 : ℚ) / (40 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q4.qr) :
    (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q4.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q4.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q4.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q4.qr truth| ≤ ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q4.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q4.qr truth| ≤ radius) ↔
      ε * (((41 : ℚ) / (40 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q4.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q4.Minimax
namespace Q5
def q (j : Fin 3) : ℚ := (((16 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((1 : ℚ) / (112 : ℚ)), ((-1 : ℚ) / (28 : ℚ)), ((-3 : ℚ) / (112 : ℚ)), ((1 : ℚ) / (28 : ℚ)), ((17 : ℚ) / (112 : ℚ)), ((9 : ℚ) / (28 : ℚ)), ((61 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((159 : ℚ) / (448 : ℚ)), ((-23 : ℚ) / (224 : ℚ)), ((3 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((9 : ℚ) / (8 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((9 : ℚ) / (8 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((9 : ℚ) / (8 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((9 : ℚ) / (8 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q5
namespace Q5.Minimax
def w (i : Fin 7) : ℚ := ([((-1 : ℚ) / (120 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((11 : ℚ) / (20 : ℚ)), ((11 : ℚ) / (24 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((-13 : ℚ) / (4 : ℚ)), ((8 : ℚ) / (15 : ℚ)), ((-1 : ℚ) / (60 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q5.q a ((61 : ℚ) / (60 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((61 : ℚ) / (60 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((61 : ℚ) / (60 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q5.qr) :
    (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q5.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q5.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q5.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q5.qr truth| ≤ ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q5.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q5.qr truth| ≤ radius) ↔
      ε * (((61 : ℚ) / (60 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q5.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q5.Minimax
namespace Q6
def q (j : Fin 3) : ℚ := (((18 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((29 : ℚ) / (112 : ℚ)), ((-3 : ℚ) / (28 : ℚ)), ((-31 : ℚ) / (112 : ℚ)), ((-1 : ℚ) / (4 : ℚ)), ((-3 : ℚ) / (112 : ℚ)), ((11 : ℚ) / (28 : ℚ)), ((113 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((911 : ℚ) / (448 : ℚ)), ((-107 : ℚ) / (224 : ℚ)), ((11 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((65 : ℚ) / (28 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((65 : ℚ) / (28 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((65 : ℚ) / (28 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((65 : ℚ) / (28 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q6
namespace Q6.Minimax
def w (i : Fin 7) : ℚ := ([((7 : ℚ) / (72 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((-13 : ℚ) / (36 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((91 : ℚ) / (72 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((103 : ℚ) / (18 : ℚ)), ((-11 : ℚ) / (9 : ℚ)), ((1 : ℚ) / (18 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q6.q a ((31 : ℚ) / (18 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((31 : ℚ) / (18 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((31 : ℚ) / (18 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q6.qr) :
    (((31 : ℚ) / (18 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q6.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((31 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q6.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((31 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q6.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q6.qr truth| ≤ ε * (((31 : ℚ) / (18 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q6.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q6.qr truth| ≤ radius) ↔
      ε * (((31 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q6.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q6.Minimax
namespace Q7
def q (j : Fin 3) : ℚ := (((24 : ℚ) / (1 : ℚ)) : ℚ) ^ j.val
def w (i : Fin 7) : ℚ := ([((193 : ℚ) / (112 : ℚ)), ((-9 : ℚ) / (28 : ℚ)), ((-163 : ℚ) / (112 : ℚ)), ((-47 : ℚ) / (28 : ℚ)), ((-111 : ℚ) / (112 : ℚ)), ((17 : ℚ) / (28 : ℚ)), ((349 : ℚ) / (112 : ℚ))] : List ℚ).getD i.val 0
def d (j : Fin 3) : ℚ := ([((4847 : ℚ) / (448 : ℚ)), ((-535 : ℚ) / (224 : ℚ)), ((51 : ℚ) / (448 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def qr (j : Fin 3) : ℝ := (q j : ℝ)
theorem dual_checked : dualCheck x w q d = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((277 : ℚ) / (28 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((277 : ℚ) / (28 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem fitted_query : dot wr yr = dot qr br :=
  dual_prediction xr yr wr qr br (fun j => (d j : ℝ))
    (fit_check_sound normal_checked) (dual_check_sound dual_checked).1
    (dual_check_sound dual_checked).2
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((277 : ℚ) / (28 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot qr truth| ≤ ε * (((277 : ℚ) / (28 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr qr truth ε
    (dual_check_sound dual_checked).1 hm
end Q7
namespace Q7.Minimax
def w (i : Fin 7) : ℚ := ([((91 : ℚ) / (72 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((-133 : ℚ) / (36 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((0 : ℚ) / (1 : ℚ)), ((247 : ℚ) / (72 : ℚ))] : List ℚ).getD i.val 0
def a (j : Fin 3) : ℚ := ([((103 : ℚ) / (18 : ℚ)), ((-11 : ℚ) / (9 : ℚ)), ((1 : ℚ) / (18 : ℚ))] : List ℚ).getD j.val 0
def wr (i : Fin 7) : ℝ := (w i : ℝ)
def ar (j : Fin 3) : ℝ := (a j : ℝ)
theorem optimality_checked : minimaxCheck x w Q7.q a ((151 : ℚ) / (18 : ℚ)) = true := by decide +kernel
theorem gain_checked : (∑ i, |w i|) = (((151 : ℚ) / (18 : ℚ)) : ℚ) := by decide +kernel
theorem real_gain : (∑ i, |wr i|) = (((151 : ℚ) / (18 : ℚ)) : ℝ) := by
  have h := congrArg (fun a : ℚ => (a : ℝ)) gain_checked
  simpa only [wr, Rat.cast_sum, Rat.cast_abs, Rat.cast_div, Rat.cast_intCast,
    Rat.cast_ofNat, Rat.cast_neg] using h
theorem globally_minimal_gain (v : Fin 7 → ℝ) (hv : Reproduces xr v Q7.qr) :
    (((151 : ℚ) / (18 : ℚ)) : ℝ) ≤ ∑ i, |v i| := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_weights_optimal xr wr Q7.qr ar h.2.1 h.2.2 v hv
  simpa only [real_gain] using hm
theorem sharp_radius (ε radius : ℝ) (he : 0 ≤ ε) :
    (∀ z : Fin 7 → ℝ, (∀ i, |z i - yr i| ≤ ε) → |dot wr z - dot wr yr| ≤ radius) ↔
      ε * (((151 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  simpa only [real_gain] using sharp_radius_iff wr yr ε radius he
theorem no_reproducing_estimator_has_smaller_radius (ε radius : ℝ) (he : 0 ≤ ε)
    (v : Fin 7 → ℝ) (hv : Reproduces xr v Q7.qr)
    (hr : ∀ z, (∀ i, |z i - yr i| ≤ ε) → |dot v z - dot v yr| ≤ radius) :
    ε * (((151 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  have hm := minimax_radius_lower_bound xr yr wr Q7.qr ar h.2.1 h.2.2 ε radius he v hv hr
  simpa only [real_gain] using hm
theorem conditional_physical_enclosure (truth : Fin 3 → ℝ) (ε : ℝ)
    (hm : ∀ i, |yr i - prediction xr truth i| ≤ ε) :
    |dot wr yr - dot Q7.qr truth| ≤ ε * (((151 : ℚ) / (18 : ℚ)) : ℝ) := by
  simpa only [real_gain] using physical_enclosure xr yr wr Q7.qr truth ε
    (minimax_check_sound optimality_checked).1 hm
theorem uniform_minimax_over_all_prediction_functions (ε radius : ℝ) (he : 0 ≤ ε) :
    (∃ estimator : (Fin 7 → ℝ) → ℝ,
      ∀ truth observed, (∀ i, |observed i - prediction xr truth i| ≤ ε) →
        |estimator observed - dot Q7.qr truth| ≤ radius) ↔
      ε * (((151 : ℚ) / (18 : ℚ)) : ℝ) ≤ radius := by
  have h := minimax_check_sound optimality_checked
  simpa only [real_gain] using
    minimax_over_all_estimators_iff xr wr Q7.qr ar h.1 h.2.1 h.2.2 ε radius he
end Q7.Minimax
end PCSCalibrationReplay.M2

#print axioms PCSCalibrationReplay.M2.normal_checked
#print axioms PCSCalibrationReplay.M2.residual_checked
#print axioms PCSCalibrationReplay.M2.global_optimum
#print axioms PCSCalibrationReplay.M2.excludes_every_better_model
#print axioms PCSCalibrationReplay.M2.uniform_error_exclusion
#print axioms PCSCalibrationReplay.M2.Q0.dual_checked
#print axioms PCSCalibrationReplay.M2.Q0.gain_checked
#print axioms PCSCalibrationReplay.M2.Q0.real_gain
#print axioms PCSCalibrationReplay.M2.Q0.fitted_query
#print axioms PCSCalibrationReplay.M2.Q0.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q0.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q0.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q1.dual_checked
#print axioms PCSCalibrationReplay.M2.Q1.gain_checked
#print axioms PCSCalibrationReplay.M2.Q1.real_gain
#print axioms PCSCalibrationReplay.M2.Q1.fitted_query
#print axioms PCSCalibrationReplay.M2.Q1.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q1.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q1.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q2.dual_checked
#print axioms PCSCalibrationReplay.M2.Q2.gain_checked
#print axioms PCSCalibrationReplay.M2.Q2.real_gain
#print axioms PCSCalibrationReplay.M2.Q2.fitted_query
#print axioms PCSCalibrationReplay.M2.Q2.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q2.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q2.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q3.dual_checked
#print axioms PCSCalibrationReplay.M2.Q3.gain_checked
#print axioms PCSCalibrationReplay.M2.Q3.real_gain
#print axioms PCSCalibrationReplay.M2.Q3.fitted_query
#print axioms PCSCalibrationReplay.M2.Q3.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q3.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q3.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q4.dual_checked
#print axioms PCSCalibrationReplay.M2.Q4.gain_checked
#print axioms PCSCalibrationReplay.M2.Q4.real_gain
#print axioms PCSCalibrationReplay.M2.Q4.fitted_query
#print axioms PCSCalibrationReplay.M2.Q4.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q4.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q4.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q5.dual_checked
#print axioms PCSCalibrationReplay.M2.Q5.gain_checked
#print axioms PCSCalibrationReplay.M2.Q5.real_gain
#print axioms PCSCalibrationReplay.M2.Q5.fitted_query
#print axioms PCSCalibrationReplay.M2.Q5.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q5.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q5.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q6.dual_checked
#print axioms PCSCalibrationReplay.M2.Q6.gain_checked
#print axioms PCSCalibrationReplay.M2.Q6.real_gain
#print axioms PCSCalibrationReplay.M2.Q6.fitted_query
#print axioms PCSCalibrationReplay.M2.Q6.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q6.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q6.Minimax.uniform_minimax_over_all_prediction_functions
#print axioms PCSCalibrationReplay.M2.Q7.dual_checked
#print axioms PCSCalibrationReplay.M2.Q7.gain_checked
#print axioms PCSCalibrationReplay.M2.Q7.real_gain
#print axioms PCSCalibrationReplay.M2.Q7.fitted_query
#print axioms PCSCalibrationReplay.M2.Q7.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q7.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.optimality_checked
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.gain_checked
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.real_gain
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.globally_minimal_gain
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.sharp_radius
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.no_reproducing_estimator_has_smaller_radius
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.conditional_physical_enclosure
#print axioms PCSCalibrationReplay.M2.Q7.Minimax.uniform_minimax_over_all_prediction_functions
