# PCS reference-control source snapshot

Pinned source: 3cfc1fff3bf0c722f968e50cf2cb874fbe44d838. This contains the original Aristotle reference algorithms and the proof-only kernel computation certificates. It contains no compiled artifacts, credentials, model checkpoints or production authority. Source identity does not confer release approval. Python/JavaScript refinement remains open.

Use the official Lean 4.28.0 release. From formal/, run:

lake build
lake build +PCSReferenceCertificates.DeMorgan:leanArts
lake build +PCSReferenceCertificates.Choices:leanArts
lake build +PCSReferenceCertificates.DenseControl:leanArts
lake build PCSControls
lake env lean PCSOmegaDDAudit.lean
lake env lean PCSOmegaDDFullAudit.lean

All three large targets must complete, not merely print intermediate progress. Standard public CI additionally checks precise semantic rejection of PCSNegative/FalseEquivalence.lean and PCSNegative/FalseWeightedMinimum.lean, source/axiom integrity and runtime boundaries. Those two negative files must fail because their false claims are rejected. Small positive controls and all original theorem statements remain unchanged. Certificate helpers are individual proof transitions, not added model benchmark tasks.
