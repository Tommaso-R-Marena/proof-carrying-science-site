"""One predeclared authored arithmetic demo; no registry or evaluator changes."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time
from pcs.experimental.prover.cli import run
from pcs.experimental.prover.language import formalize
from pcs.experimental.prover.corpus import tasks
from pcs.experimental.prover.data import structural_fingerprint,intake_feedback
from pcs.experimental.prover.environment import LeanEnvironment
from pcs.experimental.prover.model import ReasoningNetwork,imitate
ROOT=Path(__file__).parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'fresh-arithmetic-demo');p.add_argument('--models',type=Path,default=Path('/workspace/proof-carrying-science/research/lean-learning-v2'));args=p.parse_args()
OUT=args.output;OUT.mkdir(exist_ok=False);models=args.models
statement='For all natural numbers a and b, if a equals b then ((a + 0) equals b and (0 + a) equals (b + 0)).'
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
parsed=formalize(statement);assert parsed['status']=='supported'
# Independently authored typed expected meaning; not constructed by the parser.
from pcs.experimental.prover.ir import declaration,var,binary,digest
b=binary;a=var('a');c=var('b');zero={'op':'number','value':0,'type':'Nat'}
expected=declaration(['a','b'],b('implies',b('eq',a,c),b('and',b('eq',b('add',a,zero),c),b('eq',b('add',zero,a),b('add',c,zero)))),'Nat')
assert digest(expected)==digest(parsed['candidates'][0]['ir'])
fingerprint=structural_fingerprint(parsed['candidates'][0]['ir'])
assert fingerprint not in {structural_fingerprint(t['goal']) for t in tasks()}
protocol={'format':'pcs-authored-arithmetic-demo-v1','statement':statement,'source_revision':source,'source_license':'Apache-2.0','structural_fingerprint':fingerprint,'budget':96,'beam':4,'policies':['selected frozen graph policy','symbolic'],'training_if_verified':{'epochs':4,'seed':17,'automatic_promotion':False},'scope':'One new authored operational demonstration, not a benchmark, external transfer test or broad semantic fidelity proof.'}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
(OUT/'statement.txt').write_text(statement+'\n')
start=time.monotonic();results={}
for name,registry in [('learned',models),('symbolic',None)]:
 t=time.monotonic();result=run(statement,registry,budget=96);results[name]=result
 (OUT/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'policy':name,'status':result['status'],'expansions':result.get('search',{}).get('expansions'),'wall_seconds_total':time.monotonic()-t}),flush=True)
summary={'source_revision':source,'statement':statement,'status':{k:v['status'] for k,v in results.items()},'new_checkpoint':None,'production_model_changed':False,'pcs_authority':False}
if results['learned']['status']=='verified':
 registry=json.loads((models/'registry.json').read_text());entry=next(x for x in registry['models'] if x['id']==registry['selected_local_experiment'])
 model=ReasoningNetwork.load(models/entry['checkpoint'],entry['sha256'])
 env=LeanEnvironment(timeout=30)
 try:
  eligible=intake_feedback(env,results['learned']['training_feedback'],tasks(),license='Apache-2.0',source_revision=source)
  (OUT/'independently-replayed-intake.json').write_text(json.dumps(eligible,indent=2)+'\n')
  training=imitate(model,[eligible],epochs=4,seed=17)
  digest=model.save(OUT/'authored-feedback-checkpoint.json',{'parent_checkpoint_sha256':entry['sha256'],'training':training,'source_revision':source,'protocol_sha256':hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest(),'experimental':True,'promotion':False})
  ReasoningNetwork.load(OUT/'authored-feedback-checkpoint.json',digest)
  summary.update({'proof_actions':len(results['learned']['search']['receipt']['actions']),'kernel_axioms':results['learned']['search']['receipt']['kernel']['axioms'],'new_checkpoint':digest,'training':training,'heldout_improvement_evaluated':False,'model_parameters':sum(p.numel() for p in model.parameters()),'independent_expected_ir_matches':True,'limits':'Verified replay and real gradient updates only; no new held-out improvement claim or automatic model promotion.'})
 finally:env.close()
summary['wall_seconds_total']=time.monotonic()-start
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
