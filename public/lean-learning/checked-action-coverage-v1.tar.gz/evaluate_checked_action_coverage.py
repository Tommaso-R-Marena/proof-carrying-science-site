"""Frozen public authored transfer checks; no fitting or automatic promotion."""
from pathlib import Path
import gzip,hashlib,json,subprocess,time,argparse,resource
from pcs.experimental.prover.language import formalize
from pcs.experimental.prover.ir import declaration,binary,var,digest
from pcs.experimental.prover.corpus import tasks
from pcs.experimental.prover.data import structural_fingerprint
from pcs.experimental.prover.model import ReasoningNetwork
from pcs.experimental.prover.environment import LeanEnvironment,search

ROOT=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--models',type=Path,default=Path.cwd()/'research/lean-learning-v2');parser.add_argument('--feedback',type=Path,required=True);parser.add_argument('--training-trajectory',type=Path,required=True);args=parser.parse_args()
OUT=args.output;OUT.mkdir(exist_ok=False)
CORE=Path.cwd()
MODELS=args.models
UPDATED=args.feedback
UPDATED_SHA='f5f5501ca050e6c4c4e904f2dabe4c6a8c0bd0520ff1e9cc83e6db193f5c9e4a'
registry=json.loads((MODELS/'registry.json').read_text())
parent=next(e for e in registry['models'] if e['id']==registry['selected_local_experiment'])
b=binary;A=var('A');B=var('B');a=var('a');c=var('c');middle=var('b')
neg=lambda x:{'op':'not','arg':x}
zero={'op':'number','value':0,'type':'Nat'}
cases=[
 ('arithmetic-equality-chain','For all natural numbers a, b and c, if (a equals b and b equals c) then (a + 0) equals c.',declaration(['a','b','c'],b('implies',b('and',b('eq',a,middle),b('eq',middle,c)),b('eq',b('add',a,zero),c)),'Nat')),
 ('disjunction-absorption','For all propositions A and B, if (A or (A and B)) then A.',declaration(['A','B'],b('implies',b('or',A,b('and',A,B)),A))),
 ('contraposition','For all propositions A and B, if ((A implies B) and (not B)) then (not A).',declaration(['A','B'],b('implies',b('and',b('implies',A,B),neg(B)),neg(A)))),
]
known={structural_fingerprint(t['goal']) for t in tasks()}
training=json.loads(args.training_trajectory.read_text())['formalization']['candidates'][0]['ir']
known.add(structural_fingerprint(training))
for name,text,expected in cases:
 parsed=formalize(text);assert parsed['status']=='supported'
 assert digest(parsed['candidates'][0]['ir'])==digest(expected),name
 assert structural_fingerprint(expected) not in known,name
 assert structural_fingerprint(expected) not in {structural_fingerprint(g) for n,t,g in cases if n!=name}
protocol={'format':'pcs-authored-feedback-transfer-v1','source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=CORE,text=True).strip(),'source_license':'Apache-2.0','budget':96,'depth':18,'beam':4,'parent_checkpoint_sha256':parent['sha256'],'feedback_checkpoint_sha256':UPDATED_SHA,'tasks':[{'id':n,'statement':t,'expected_typed_ir':g,'structural_fingerprint':structural_fingerprint(g)} for n,t,g in cases],'training_on_evaluation':False,'promotion':False,'scope':'Public development regressions after action-layer fixes informed by the earlier frozen failures. Not untouched evaluation, learned improvement or statistical superiority.'}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[];start=time.monotonic();cpu_before=resource.getrusage(resource.RUSAGE_SELF);child_before=resource.getrusage(resource.RUSAGE_CHILDREN)
for name,text,goal in cases:
 for policy in ['parent','feedback','symbolic']:
  model=ReasoningNetwork.load(MODELS/parent['checkpoint'],parent['sha256']) if policy=='parent' else ReasoningNetwork.load(UPDATED,UPDATED_SHA) if policy=='feedback' else None
  env=LeanEnvironment(timeout=30)
  try:
   result=search(env,goal,model.rank if model else None,budget=96,depth=18,beam=4)
  finally:env.close()
  artifact=f'{name}-{policy}.json.gz'
  (OUT/artifact).write_bytes(gzip.compress(json.dumps(result,indent=2).encode(),mtime=0))
  row={'task':name,'policy':policy,'status':result['status'],'expansions':result['expansions'],'lean_invocations':result['lean_invocations'],'search_wall_seconds':result['wall_seconds'],'artifact':artifact}
  if result['status']=='verified':
   receipt=result['receipt'];proof=OUT/f'{name}-{policy}.lean'
   proof.write_text('import Std\ntheorem checked_result : '+receipt['statement']+' := by\n'+receipt['proof']+'\n#print axioms checked_result\n')
   checked=subprocess.run(['lean',str(proof)],cwd=CORE,text=True,capture_output=True)
   (OUT/f'{name}-{policy}-standalone-kernel.log').write_text(checked.stdout+checked.stderr)
   assert checked.returncode==0,name+' '+policy
   row.update({'proof_steps':len(receipt['actions']),'axioms':receipt['kernel']['axioms'],'fresh_standalone_kernel_exit':checked.returncode,'proof_file':proof.name})
  rows.append(row);print(json.dumps(row),flush=True)
summary={'format':protocol['format'],'source_revision':protocol['source_revision'],'protocol_sha256':hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest(),'results':rows,'verified_counts':{p:sum(r['status']=='verified' for r in rows if r['policy']==p) for p in ['parent','feedback','symbolic']},'tasks_per_policy':3,'wall_seconds_including_verification':time.monotonic()-start,'no_evaluation_training':True,'production_model_changed':False,'statistical_superiority_established':False,'pcs_authority':False,'process_cpu_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime-cpu_before.ru_utime-cpu_before.ru_stime,'child_cpu_seconds':resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime-child_before.ru_utime-child_before.ru_stime,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'gpu_count':0,'additional_training_updates':0}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
