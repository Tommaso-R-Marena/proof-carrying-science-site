import Std
theorem checked_result : ∀ (a : Nat) (b : Nat) (c : Nat), (((a = b) ∧ (b = c)) → ((a + (0 : Nat)) = c)) := by
  intro h0
  intro h1
  intro h2
  intro h3
  rw [h3.1]
  rw [h3.2]
  simp only [Nat.add_zero, Nat.zero_add, Nat.mul_zero, Nat.zero_mul, Nat.mul_one, Nat.one_mul]
#print axioms checked_result
