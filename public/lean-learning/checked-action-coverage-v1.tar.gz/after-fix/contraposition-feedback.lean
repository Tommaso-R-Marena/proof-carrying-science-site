import Std
theorem checked_result : ∀ (A : Prop) (B : Prop), (((A → B) ∧ (¬ B)) → (¬ A)) := by
  intro h0
  intro h1
  intro h2
  intro h3
  apply h2.2
  apply h2.1
  exact h3
#print axioms checked_result
