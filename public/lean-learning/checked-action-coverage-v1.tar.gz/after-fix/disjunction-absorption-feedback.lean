import Std
theorem checked_result : ∀ (A : Prop) (B : Prop), ((A ∨ (A ∧ B)) → A) := by
  intro h0
  intro h1
  intro h2
  rcases h2 with h3 | h3
  exact h3
  exact h3.1
#print axioms checked_result
