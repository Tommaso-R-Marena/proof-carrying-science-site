# Checked Lean action coverage: actual development evidence

Core action-source revision: 1dff9843854c2b3ad99cd2b22b7f6880e6823ac0. This is an authored Apache-2.0 diagnostic and regression collection, not private blind evaluation. The original three tasks were frozen before execution of the parent, arithmetic-feedback and symbolic policies. All returned unknown (0/3 each). Independent manual controls checked afterward prove all three with no axioms; those solutions were not used in fitting or retrieval.

The action layer was repaired after inspecting these failures: introductions/applications for negation, projected-equality rewrites, and accessible fresh names after disjunction splitting. Post-repair development regressions solve 3/3 with each unchanged policy, under the same 96 expansions / depth18 / beam4 bounds. Nine completed runs on three tasks are not nine distinct theorems. Each exported proof is checked again by a standalone Lean process. The parent needs 33 arithmetic expansions versus feedback37; feedback is not promoted and no learned superiority is claimed. There are zero additional gradient updates in this collection.

The before-fix checkpoint experiment source is 4190a40831e34d14c878b25d26b23c8cdcbe8638. The feedback checkpoint was previously fitted only on the separate authored arithmetic demonstration at 3cfc1fff3bf0c722f968e50cf2cb874fbe44d838. Its original training protocol/source/checkpoint bundle remains separate and unchanged. Frozen earlier research manifests and RL metrics are not relabeled as current measurements.

## Reproduce the fixed-source development checks

Use the PCS core checkout at the exact action-source revision, hash-pinned prover dependencies and official Lean 4.28.0. From the repository root, after extracting this artifact:

```sh
python /path/to/evaluate_checked_action_coverage.py --models "$PWD/research/lean-learning-v2" --feedback /path/to/authored-feedback-checkpoint.json --training-trajectory /path/to/arithmetic-training-trajectory.json --output NEW_ACTION_RUN
PCS_REQUIRE_PROVER=1 python -m pytest -q tests/test_lean_learning_loop.py
lean /path/to/after-fix/disjunction-absorption-parent.lean
```

Output directories must be new. The script performs independently typed meaning comparisons, enforces nonduplication with corpus/training, freezes the protocol before searches, loads pinned JSON checkpoint bytes, records failed attempts and independently recompiles completed proofs. It never fits evaluation tasks, updates the registry or authorizes scientific acceptance. The reference Lean kernel/observer and registered checkpoint bytes are unchanged by the action repair. Generated candidate tactics are proposals; the immutable original theorem and verifier determine success.

Runtime-source hashes separately identify this action overlay. Prior core research snapshots retain their historical identities. All result JSON files ending in .gz use deterministic gzip; decompress them before JSON parsing. The manifest binds every member excluding itself. No credentials, compiled binaries, paid service, GPU, production D1 mutation or fabricated human game trajectory is included.
