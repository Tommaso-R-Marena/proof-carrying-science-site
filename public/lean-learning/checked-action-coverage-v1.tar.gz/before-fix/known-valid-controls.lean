import Std

-- These independently authored solutions were checked only after every frozen
-- search completed. They were not available to the policies or used for fitting.
theorem arithmetic_equality_chain :
    ∀ (a b c : Nat), (a = b ∧ b = c) → a + 0 = c := by
  intro a b c h
  simpa only [Nat.add_zero] using h.1.trans h.2

theorem disjunction_absorption :
    ∀ (A B : Prop), (A ∨ (A ∧ B)) → A := by
  intro A B h
  cases h with
  | inl hA => exact hA
  | inr hAB => exact hAB.1

theorem contraposition :
    ∀ (A B : Prop), ((A → B) ∧ ¬B) → ¬A := by
  intro A B h hA
  exact h.2 (h.1 hA)

#print axioms arithmetic_equality_chain
#print axioms disjunction_absorption
#print axioms contraposition
